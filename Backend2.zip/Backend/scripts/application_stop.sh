#!/bin/bash
#stopping existing node servers
echo "Stopping any existing node servers"
sudo pkill node
