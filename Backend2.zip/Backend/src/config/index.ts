'use strict';

export { SERVER } from './Enviornment';   
